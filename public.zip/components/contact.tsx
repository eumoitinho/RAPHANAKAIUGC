import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Send, Mail, Phone, MapPin, Instagram } from "lucide-react"

export function Contact() {
  return (
    <section id="contato" className="py-24 bg-[#1e1e1e]">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-4xl font-serif italic mb-16 text-center text-[#d87093]">Contato</h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Contact Form */}
          <div>
            <form className="space-y-6">
              <div className="space-y-4">
                <Input placeholder="Nome" className="bg-[#252525] border-[#333333] focus:border-[#d87093] text-white" />

                <Input
                  type="email"
                  placeholder="Email"
                  className="bg-[#252525] border-[#333333] focus:border-[#d87093] text-white"
                />

                <Input
                  placeholder="Assunto"
                  className="bg-[#252525] border-[#333333] focus:border-[#d87093] text-white"
                />

                <Textarea
                  placeholder="Mensagem"
                  className="bg-[#252525] border-[#333333] focus:border-[#d87093] text-white min-h-[150px]"
                />
              </div>

              <Button className="w-full bg-[#d87093] hover:bg-[#c45c7c] text-white">
                <span className="flex items-center">
                  Enviar <Send size={16} className="ml-2" />
                </span>
              </Button>
            </form>
          </div>

          {/* Contact Info */}
          <div className="flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-medium mb-6 text-white">Informações de Contato</h3>

              <ul className="space-y-6">
                <li className="flex items-start">
                  <Mail className="mr-4 mt-1 text-[#d87093]" size={20} />
                  <div>
                    <p className="text-gray-400">Email</p>
                    <a href="mailto:contato@raphanakai.com.br" className="hover:text-[#d87093] transition-colors">
                      contato@raphanakai.com.br
                    </a>
                  </div>
                </li>

                <li className="flex items-start">
                  <Phone className="mr-4 mt-1 text-[#d87093]" size={20} />
                  <div>
                    <p className="text-gray-400">Telefone</p>
                    <a href="tel:+5511999999999" className="hover:text-[#d87093] transition-colors">
                      +55 (11) 99999-9999
                    </a>
                  </div>
                </li>

                <li className="flex items-start">
                  <MapPin className="mr-4 mt-1 text-[#d87093]" size={20} />
                  <div>
                    <p className="text-gray-400">Localização</p>
                    <p>São Paulo, SP - Brasil</p>
                  </div>
                </li>
              </ul>
            </div>

            <div className="mt-12">
              <h3 className="text-xl font-medium mb-6 text-white">Redes Sociais</h3>

              <div className="flex space-x-4">
                <a
                  href="https://instagram.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#252525] flex items-center justify-center hover:bg-[#d87093] transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram size={20} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

