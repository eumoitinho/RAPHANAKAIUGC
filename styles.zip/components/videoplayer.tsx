"use client"

import { useRef, useEffect, useState } from 'react'
import { Play, Pause, Volume2, VolumeX } from 'lucide-react'

interface VideoPlayerProps {
  src: string
  thumbnail?: string
  title?: string
  className?: string
}

export function VideoPlayer({ src, thumbnail, title, className = "" }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(true) // Iniciar mutado para evitar problemas de autoplay
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showControls, setShowControls] = useState(false)

  // Debug: Log inicial
  useEffect(() => {
    console.log('🎬 VideoPlayer montado:', { src, thumbnail, title })
  }, [])

  useEffect(() => {
    const video = videoRef.current
    if (!video) {
      console.warn('❌ VideoPlayer: elemento video não encontrado')
      return
    }

    console.log('🔧 Configurando video element:', {
      src,
      currentSrc: video.currentSrc,
      readyState: video.readyState,
      networkState: video.networkState
    })

    const handleLoadStart = () => {
      console.log('📡 Video: iniciando carregamento')
      setIsLoading(true)
      setError(null)
    }

    const handleLoadedData = () => {
      console.log('✅ Video: dados carregados:', {
        duration: video.duration,
        videoWidth: video.videoWidth,
        videoHeight: video.videoHeight,
        readyState: video.readyState
      })
      setIsLoading(false)
      setError(null)
    }

    const handleLoadedMetadata = () => {
      console.log('📋 Video: metadados carregados:', {
        duration: video.duration,
        dimensions: `${video.videoWidth}x${video.videoHeight}`,
        currentTime: video.currentTime
      })
    }

    const handleCanPlay = () => {
      console.log('✅ Video: pronto para reprodução')
      setIsLoading(false)
    }

    const handleCanPlayThrough = () => {
      console.log('🚀 Video: pode reproduzir sem interrupções')
    }

    const handleError = (e: Event) => {
      const target = e.target as HTMLVideoElement
      const error = target.error
      
      console.error('❌ Erro no vídeo:', {
        code: error?.code,
        message: error?.message,
        src: video.src,
        currentSrc: video.currentSrc,
        networkState: video.networkState,
        readyState: video.readyState
      })
      
      let errorMessage = 'Erro ao carregar o vídeo'
      
      if (error?.code === MediaError.MEDIA_ERR_ABORTED) {
        errorMessage = 'Carregamento do vídeo foi interrompido'
      } else if (error?.code === MediaError.MEDIA_ERR_NETWORK) {
        errorMessage = 'Erro de rede ao carregar vídeo'
      } else if (error?.code === MediaError.MEDIA_ERR_DECODE) {
        errorMessage = 'Erro ao decodificar vídeo'
      } else if (error?.code === MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED) {
        errorMessage = 'Formato de vídeo não suportado'
      }
      
      setError(errorMessage)
      setIsLoading(false)
    }

    const handlePlay = () => {
      console.log('▶️ Video: reprodução iniciada')
      setIsPlaying(true)
    }
    
    const handlePause = () => {
      console.log('⏸️ Video: pausado')
      setIsPlaying(false)
    }
    
    const handleEnded = () => {
      console.log('⏹️ Video: finalizado')
      setIsPlaying(false)
    }

    const handleWaiting = () => {
      console.log('⏳ Video: aguardando buffer')
    }

    const handlePlaying = () => {
      console.log('🎬 Video: reproduzindo efetivamente')
    }

    const handleStalled = () => {
      console.warn('⚠️ Video: carregamento pausado')
    }

    const handleSuspend = () => {
      console.log('💤 Video: carregamento suspenso')
    }

    // Reset state when src changes
    setIsLoading(true)
    setError(null)
    setIsPlaying(false)

    // Adicionar todos os event listeners
    video.addEventListener('loadstart', handleLoadStart)
    video.addEventListener('loadeddata', handleLoadedData)
    video.addEventListener('loadedmetadata', handleLoadedMetadata)
    video.addEventListener('canplay', handleCanPlay)
    video.addEventListener('canplaythrough', handleCanPlayThrough)
    video.addEventListener('error', handleError)
    video.addEventListener('play', handlePlay)
    video.addEventListener('pause', handlePause)
    video.addEventListener('ended', handleEnded)
    video.addEventListener('waiting', handleWaiting)
    video.addEventListener('playing', handlePlaying)
    video.addEventListener('stalled', handleStalled)
    video.addEventListener('suspend', handleSuspend)

    return () => {
      video.removeEventListener('loadstart', handleLoadStart)
      video.removeEventListener('loadeddata', handleLoadedData)
      video.removeEventListener('loadedmetadata', handleLoadedMetadata)
      video.removeEventListener('canplay', handleCanPlay)
      video.removeEventListener('canplaythrough', handleCanPlayThrough)
      video.removeEventListener('error', handleError)
      video.removeEventListener('play', handlePlay)
      video.removeEventListener('pause', handlePause)
      video.removeEventListener('ended', handleEnded)
      video.removeEventListener('waiting', handleWaiting)
      video.removeEventListener('playing', handlePlaying)
      video.removeEventListener('stalled', handleStalled)
      video.removeEventListener('suspend', handleSuspend)
    }
  }, [src])

  const togglePlay = async () => {
    const video = videoRef.current
    if (!video) return

    try {
      if (isPlaying) {
        console.log('⏸️ Pausando vídeo')
        video.pause()
      } else {
        console.log('▶️ Reproduzindo vídeo:', src)
        
        // Forçar carregamento se necessário
        if (video.readyState < 2) {
          video.load()
        }
        
        // Tentar reproduzir
        const playPromise = video.play()
        
        if (playPromise !== undefined) {
          await playPromise
          console.log('✅ Reprodução iniciada com sucesso')
        }
      }
    } catch (error) {
      console.error('❌ Erro ao reproduzir/pausar vídeo:', error)
      setIsLoading(false)
      
      if (error instanceof Error) {
        if (error.name === 'NotAllowedError') {
          setError('Reprodução bloqueada pelo navegador. Clique para permitir.')
        } else if (error.name === 'NotSupportedError') {
          setError('Formato de vídeo não suportado')
        } else {
          setError(`Erro de reprodução: ${error.message}`)
        }
      } else {
        setError('Erro ao reproduzir o vídeo')
      }
    }
  }

  const toggleMute = () => {
    const video = videoRef.current
    if (!video) return
    
    video.muted = !video.muted
    setIsMuted(video.muted)
  }

  if (error) {
    return (
      <div className={`relative bg-black rounded-lg overflow-hidden ${className}`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white p-4">
            <p className="text-sm">{error}</p>
            <button 
              onClick={() => {
                setError(null)
                setIsLoading(true)
                videoRef.current?.load()
              }}
              className="mt-2 px-4 py-2 bg-[#d87093] rounded text-sm hover:bg-[#c45c7c] transition-colors"
            >
              Tentar novamente
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div 
      className={`relative bg-black rounded-lg overflow-hidden group ${className}`}
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
    >
      <video
        ref={videoRef}
        src={src}
        poster={thumbnail}
        className="w-full h-full object-cover"
        preload="metadata"
        playsInline
        muted={isMuted}
        controls={false}
        onContextMenu={(e) => e.preventDefault()}
      >
        Seu navegador não suporta o elemento de vídeo.
      </video>

      {/* Loading Spinner */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#d87093]"></div>
        </div>
      )}

      {/* Play/Pause Overlay */}
      <div 
        className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-20 transition-all duration-200 cursor-pointer"
        onClick={togglePlay}
      >
        {!isPlaying && !isLoading && (
          <div className="bg-black bg-opacity-60 rounded-full p-4 transform scale-100 hover:scale-110 transition-transform">
            <Play className="w-8 h-8 text-white ml-1" fill="white" />
          </div>
        )}
      </div>

      {/* Controls */}
      {(showControls || isPlaying) && !isLoading && (
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/50 to-transparent p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  togglePlay()
                }}
                className="text-white hover:text-[#d87093] transition-colors"
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5" />
                ) : (
                  <Play className="w-5 h-5" />
                )}
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  toggleMute()
                }}
                className="text-white hover:text-[#d87093] transition-colors"
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>
            </div>

            {title && (
              <div className="text-white text-sm truncate max-w-[200px]">
                {title}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}